﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NLog;
using System.Globalization;


namespace CS_TimeSheet
{
    public partial class frmCS201 : Form
    {
        // Logger
        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();
        //使用公共變數傳值
        public string mode = string.Empty;
        //使用公共變數 LIST傳值
        public List<string> myEmpList = new List<string>();

        public frmCS201()
        {
            InitializeComponent();
            initData();
            Databinding();
        }





        private void bntQuery_Click(object sender, EventArgs e)
        {
            Handle_SQL handle_SQL = new Handle_SQL();
            string sSql;


            sSql = @"select   work_day as 工作日期,  cust_name as 客戶名稱, work_loc as  工作區域, wo_no as 服務單, 
                   mach_no as 機型, emp_no as 工號, emp_name as 姓名, service_item as 工作項目,
                   service_desc as 工作進度, wrok_hour as 工時 , seq_no as 報工單序號 , category 機構 from   public.cs_timesheet  where  1=1 ";
            // where condition
            if (comboEmpNo_Q.Text != "")
            {
                sSql += " and  emp_no ='" + comboEmpNo_Q.SelectedValue.ToString().Split(',')[0] + "'";
            }

            sSql += " and  work_day between '" + dt_Start.Value.ToString("yyyyMMdd") + "' and '" + dt_End.Value.ToString("yyyyMMdd") + "'";


            //if (txEmpNo.Text != "")
            //{
            //    sSql = sSql + " and  emp_no ='" + txEmpNo.Text + "'";
            //}

            logger.Trace(sSql);

            DataTable dDT = new DataTable();
            dDT = handle_SQL.Query(sSql);
            dataGridView1.DataSource = dDT;

            //  dataGridView1.SelectedRows[0].Cells["工作區域"] 
            dataGridView1.Columns["工作區域"].Visible = false;
            dataGridView1.Columns["服務單"].Visible = false;

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void btnDel_Click(object sender, EventArgs e)
        {

        }

        private void frmCS101_Validated(object sender, EventArgs e)
        {
            MessageBox.Show("frmCS101_Activated !!", "OK");
        }

        private void initData()
        {
            Handle_SQL handle_SQL = new Handle_SQL();
            string sSql;

            sSql = "select     cust_no  ,cust_name   from   cs_cust where  1=1 ";
            // where condition
            logger.Trace(sSql);

            DataTable dDT = new DataTable();
            dDT = handle_SQL.Query(sSql);
            //處理  AutoCompleteTextBox

            initAutoCompleteTextBox(dDT, "txCust");


        }

        private void initAutoCompleteTextBox(DataTable dDT, string sStr)
        {
            AutoCompleteStringCollection autoData = new AutoCompleteStringCollection();

            switch (sStr)
            {
                case "txCust":
                    foreach (DataRow dr in dDT.Rows)
                    {
                        autoData.Add(dr["cust_name"].ToString());
                    }
                    txCust.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txCust.AutoCompleteMode = AutoCompleteMode.Suggest;
                    txCust.AutoCompleteCustomSource = autoData;
                    break;


            }







        }


        private void Databinding()
        {
            Handle_SQL handle_SQL = new Handle_SQL();
            string sSql;

            sSql = "select     concat(emp_no, ',', emp_name) emp_no from   cs_staff where  1=1 ";
            // where condition
            logger.Trace(sSql);

            DataTable dDT = new DataTable("cs_staff");
            DataTable qDT = new DataTable("staff");
            dDT = handle_SQL.Query(sSql);

            DataRow dr = dDT.NewRow();
            dDT.Rows.InsertAt(dr, 0); //插入到第一行
            qDT = dDT.Copy();
            comboEmpNo.DataSource = dDT;
            comboEmpNo_Q.DataSource = qDT;
         
            comboEmpNo.DisplayMember = "工號";
            comboEmpNo.ValueMember = "emp_no";
            comboEmpNo_Q.DisplayMember = "工號";
            comboEmpNo_Q.ValueMember = "emp_no";



        }

        private void comboEmpNo_DropDownClosed(object sender, EventArgs e)
        {

        }

        private void comboEmpNo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            // txEmp_name.Text = comboEmpNo.SelectedValue.ToString().Split(',')[1];
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            string sMsg = string.Empty;
            string _seq = string.Empty;
            long iSeq = 0;
            sMsg = Validations();

            if (sMsg == "")
            {
                _seq = Get_SeqNo();
                if (_seq != "")
                {
                    if (_seq.Substring(0, 6) == DateTime.Now.ToString("yyMMdd"))
                    {
                        iSeq = long.Parse(_seq)+1;
                        _seq = iSeq.ToString()  ;
                    }
                    else
                    {
                        _seq = DateTime.Now.ToString("yyMMdd") + "001";
                    }
                }
                else
                {
                    _seq = DateTime.Now.ToString("yyMMdd") + "001";
                }

                rtxService_desc.Text = rtxService_desc.Text.Replace("\r\n", "");
                rtxService_desc.Text = rtxService_desc.Text.Replace("\n", "");
                rtxService_desc.Text = rtxService_desc.Text.Replace("\r", "");
                // insert data 
                DataInsert(_seq);
            }
            else
            {
                MessageBox.Show(sMsg, "售服報工作業", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // dataGridView1.RefreshEdit
            bntQuery.PerformClick();
           }

        // 資料insert 
        private void DataInsert(string _seq)
        {
            try
            {
                Handle_SQL handle_SQL = new Handle_SQL();

                string insertSql;

                  insertSql = string.Format(@"INSERT INTO public.cs_timesheet(work_day, cust_name, work_loc,wo_no,  
                                                                            mach_no, emp_no, emp_name, service_item,
                                                                            service_desc, wrok_hour, create_user,seq_no,category)
                                            VALUES('{0}', '{1}', '{2}', '{3}',
                                                    '{4}', '{5}', '{6}', '{7}', 
                                                    '{8}','{9}',    'sys','{10}','{11}')",
                                    dateTimePicker1.Value.ToString("yyyyMMdd"), txCust.Text, comboLoc.Text, txWorkNO.Text,
                                    tcMach_no.Text, comboEmpNo.SelectedValue.ToString().Split(',')[0], comboEmpNo.SelectedValue.ToString().Split(',')[1], comboItem.Text,
                                    rtxService_desc.Text, txWH.Text,_seq, comboCategory.Text);

                logger.Trace(insertSql);
                handle_SQL.Insert(insertSql);
                MessageBox.Show("資料新增完成 !!", "售服報工作業", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {

                logger.Error(ex, "Error");
                MessageBox.Show("資料新增失敗 !!" + "\r\n", "售服報工作業", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void frmCS201_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Value = DateTime.Today;
            //查詢用
            dt_Start.Value = DateTime.Today.AddDays(-8); ;
            dt_End.Value = DateTime.Today;
        }

        private void txWH_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (((int)e.KeyChar < 48 | (int)e.KeyChar > 57) & (int)e.KeyChar != 8)
            {
                e.Handled = true;
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void dt_End_ValueChanged(object sender, EventArgs e)
        {
            if (dt_Start.Value > dt_End.Value)
            {
                MessageBox.Show("查詢日期 !!" + "\r\n 起 :" + dt_Start.Value.ToString("yyyyMMdd") + "\r\n 大於\r\n 迄 :" + dt_End.Value.ToString("yyyyMMdd"), " 售服報工作業", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private string Validations()
        {
            if (string.IsNullOrWhiteSpace(comboEmpNo.Text))
                return "工號不可空白!";
            if (string.IsNullOrWhiteSpace(comboLoc.Text))
                return "工作地點不可空白!";
            if (string.IsNullOrWhiteSpace(comboItem.Text))
                return "工作項目不可空白!";
            if (string.IsNullOrWhiteSpace(txWH.Text))
                return "工時不可空白!";
            if (string.IsNullOrWhiteSpace(txCust.Text))
                return "客戶不可空白!";
            if (string.IsNullOrWhiteSpace(comboCategory.Text))
                return "機構不可空白!";
            return string.Empty;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.GetCellCount(DataGridViewElementStates.Selected) > 0 )
            {
                string sMsg;

                sMsg =  "報工日期 : " + dateTimePicker1.Value.ToString("yyyyMMdd") + "\r\n工號 : "+  comboEmpNo.SelectedValue ;
                DialogResult Result = MessageBox.Show("是否修改報工作業資料"+"\r\n"+ sMsg, "售服報工作業", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                if (Result == DialogResult.OK)
                {
                   
                    DataUpdate();
                }
                else if (Result == DialogResult.Cancel)
                {
                    //MessageBox.Show("按下Cancel", "");
                }
               
            }

            else
            {
                MessageBox.Show("請先查詢後再選擇資料修改  !!" + "\r\n", "售服報工作業", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

        }

        // 資料UPDATE  seq
        private void DataUpdate( )
        {
            try
            {

                Handle_SQL handle_SQL = new Handle_SQL();

                string updSql;
                updSql = string.Format(@" UPDATE  public.cs_timesheet SET work_day = '{0}', cust_name ='{1}', work_loc ='{2}', 
                                 mach_no = '{3}', service_item = '{4}', service_desc = '{5}',
                                 wrok_hour = '{6}' , wo_no = '{7}' WHERE seq_no = '{8}'; ",
                                 dateTimePicker1.Value.ToString("yyyyMMdd"), txCust.Text, comboLoc.Text, tcMach_no.Text,
                                 comboItem.Text,rtxService_desc.Text, txWH.Text, txWorkNO.Text, dataGridView1.SelectedRows[0].Cells["報工單序號"].Value.ToString() );
       


                logger.Trace(updSql);
                handle_SQL.Update(updSql);
                MessageBox.Show("資料修改完成 !!", "售服報工作業", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {

                logger.Error(ex, "Error");
                MessageBox.Show("資料修改失敗 !!" + "\r\n", "售服人員資料維護", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            Int32 selectedCellCount = dataGridView1.GetCellCount(DataGridViewElementStates.Selected);
            if (selectedCellCount > 0)
            {
                comboEmpNo.Enabled = false;
                dateTimePicker1.Value = DateTime.ParseExact(dataGridView1.SelectedRows[0].Cells[0].Value.ToString(), "yyyyMMdd", DateTimeFormatInfo.InvariantInfo);
                comboEmpNo.SelectedIndex = comboEmpNo.FindString(dataGridView1.SelectedRows[0].Cells[5].Value.ToString());
                txWorkNO.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                tcMach_no.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                comboLoc.SelectedIndex = comboLoc.FindString(dataGridView1.SelectedRows[0].Cells[2].Value.ToString());
                comboItem.SelectedIndex = comboItem.FindString(dataGridView1.SelectedRows[0].Cells[7].Value.ToString());
                txWH.Text = dataGridView1.SelectedRows[0].Cells[9].Value.ToString();
                txCust.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                rtxService_desc.Text = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();

                if (dataGridView1.SelectedRows[0].Cells[11].Value.ToString() != "")
                {
                   comboCategory.SelectedIndex = comboCategory.FindString(dataGridView1.SelectedRows[0].Cells[11].Value.ToString() );
                }
                else
                {
                    comboCategory.SelectedIndex = -1;
                }


            }
           

            comboEmpNo.Enabled = true;

        }

        private string Get_SeqNo()
        {
            Handle_SQL handle_SQL = new Handle_SQL();
            string sSql, rtnStr;

            sSql = @"select   Max(seq_no) seq_no from   public.cs_timesheet    ";

            logger.Trace(sSql);

            DataTable dDT = new DataTable();
            dDT = handle_SQL.Query(sSql);
            rtnStr = dDT.Rows[0]["seq_no"].ToString();
            return rtnStr;
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                Point p = MousePosition;//取得滑鼠位置
                contextMenuStrip1.Show(p);//顯示右鍵選單
            }
        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                Handle_SQL handle_SQL = new Handle_SQL();

                string delSql;
                delSql = string.Format(@" delete  from public.cs_timesheet where seq_no='{0}' ", dataGridView1.SelectedRows[0].Cells["報工單序號"].Value.ToString());

                logger.Trace(delSql);
                handle_SQL.Insert(delSql);
                MessageBox.Show("資料刪除完成 !!", "售服報工作業", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {

                logger.Error(ex, "Error");
                MessageBox.Show("資料刪除失敗 !!" + "\r\n", "售服報工作業", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txWorkNO.Text = "";
            tcMach_no.Text = "";
            txWH.Text = "";
            txCust.Text = "";
            comboLoc.SelectedIndex = -1;
            comboItem.SelectedIndex = -1;
            comboEmpNo.SelectedIndex = -1;
            dateTimePicker1.Value = DateTime.Today ;


        }

        private void comboItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboItem.Text == "送貨")
            {

            }
            else
            {

            }
        }

        private void btnDel_Click_1(object sender, EventArgs e)
        {

        }
    }
}
