﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NLog;


namespace CS_TimeSheet
{
    public partial class frmCS101 : Form
    {
       // Logger
        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();
       //使用公共變數傳值
        public string mode = string.Empty;
       //使用公共變數 LIST傳值
        public List<string> myEmpList = new List<string>() ;

        public frmCS101()
        {
            InitializeComponent();

        }

        private void btnNew_Click(object sender, EventArgs e)
        {

            mode = "A"; // APPEND
            frmCS101ea form2 = new frmCS101ea(mode);

            //form2.Show(this);
            //設定Form2為Form1的上層，並開啟Form2視窗。由於在Form1的程式碼內使用this，所以this為Form1的物件本身
            form2.ShowDialog(this);
            //if (form2.DialogResult == System.Windows.Forms.DialogResult.OK)
            //{
            //    //若使用者在Form2按下了OK，則進入這個判斷式
            //    textBox1.Text = "按下了" + form2.DialogResult.ToString();
            //}
            //else if (form2.DialogResult == System.Windows.Forms.DialogResult.Cancel)
            //{
            //    //若使用者在Form2按下了Cancel或者直接點選X關閉視窗，都會進入這個判斷式
            //    textBox1.Text = "按下了" + form2.DialogResult.ToString();
            //}
            //else
            //{
            //    textBox1.Text = "按下了" + form2.DialogResult.ToString();
            //}


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bntQuery_Click(object sender, EventArgs e)
        {
            Handle_SQL handle_SQL = new Handle_SQL();
            string sSql;

            //sSql = string.Format("select   [dep_no]  as  部門代碼 ,[emp_no] as 員工編號,[emp_name] as 員工姓名 from   CS_staff where emp_no= '{0}' ", txEmpNo.Text);
            sSql = "select    dep_no   as  部門代碼 , emp_no as 員工編號,emp_name as 員工姓名 from   cs_staff where  1=1 ";
            // where condition
            if (txDept.Text != "")
            {
                sSql = sSql + " and  dep_no ='" + txDept.Text + "'";
            }

            if (txEmp_name.Text != "")
            {
                sSql = sSql + " and  emp_name ='" + txEmp_name.Text + "'";
            }

            if (txEmpNo.Text != "")
            {
                sSql = sSql + " and  emp_no ='" + txEmpNo.Text + "'";
            }

            logger.Trace(sSql);

            DataTable dDT = new DataTable();
            dDT = handle_SQL.Query(sSql);
            dataGridView1.DataSource = dDT;

            
             

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            mode = "E"; // Edit
 

            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("請先選取資料後再修改", "基本資料維護", MessageBoxButtons.OK);
                return;
            }
            // 取出 dataGridView1目前的座標 
            int i = dataGridView1.CurrentCell.RowIndex;
            int j = dataGridView1.CurrentCell.ColumnIndex;
             
            myEmpList.Clear();
            // dep_no
            myEmpList.Add(dataGridView1.Rows[i].Cells[0].Value.ToString());
            // emp_no
            myEmpList.Add(dataGridView1.Rows[i].Cells[1].Value.ToString());
            // emp_name
            myEmpList.Add(dataGridView1.Rows[i].Cells[2].Value.ToString());


            frmCS101ea form2 = new frmCS101ea(mode);

            form2._emp = myEmpList;

            form2.Show(this);

        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            

            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("請先選取資料後再刪除", "基本資料維護", MessageBoxButtons.OK);
                return;
            }
            // 取出 dataGridView1目前的座標 
            int i = dataGridView1.CurrentCell.RowIndex;
            int j = dataGridView1.CurrentCell.ColumnIndex;

            
            try
            {

                Handle_SQL handle_SQL = new Handle_SQL();

                string delSql;

                delSql = string.Format("DELETE FROM  cs_staff WHERE emp_no ='{0}'   ", dataGridView1.Rows[i].Cells[1].Value.ToString() );
                logger.Trace(delSql);
                handle_SQL.Delete(delSql);
                MessageBox.Show("資料刪除完成 !!", "售服人員資料維護", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {

                logger.Error(ex, "Error");
                MessageBox.Show("資料刪除失敗 !!" + "\r\n"  , "售服人員資料維護", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }


        }

        private void frmCS101_Validated(object sender, EventArgs e)
        {
            MessageBox.Show("frmCS101_Activated !!", "OK");
        }

        private void frmCS101_Load(object sender, EventArgs e)
        {
            

        }


       

        //public DataTable GetData(string selectSql)
        //{
        //    try
        //    {
        //        DataSet ds = new DataSet();
        //        string connstring = String.Format("Your conn string");

        //        NpgsqlConnection conn = new NpgsqlConnection(connstring);
        //        conn.Open();
        //        NpgsqlDataAdapter da = new NpgsqlDataAdapter(selectSql, conn);
        //        da.Fill(ds);
        //        return ds.Tables[0];
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }
        //}
    }
}
