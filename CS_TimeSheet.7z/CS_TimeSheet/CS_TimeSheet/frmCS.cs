﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS_TimeSheet
{
    public partial class frmCS : Form
    {
        public frmCS()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem101_Click(object sender, EventArgs e)
        {
            frmCS101 frmCS101 = new frmCS101();
            frmCS101.Show(this);
            

        }

        private void toolStripMenuItem102_Click(object sender, EventArgs e)
        {
            //frmCS102 frmCS102 = new frmCS102();
            //frmCS102.ShowDialog(this);
        }

        private void frm_Load(object sender, EventArgs e)
        {

        }

        private void   ToolStripMenuItem201_Click(object sender, EventArgs e)
        {
            //售服報工作業
            frmCS201 frmCS201 = new frmCS201();
            frmCS201.Show(this);
        }

        private void ToolStripMenuItem202_Click(object sender, EventArgs e)
        {
            //售服報工作業
            FrmCS202 FrmCS202 = new FrmCS202();
            FrmCS202.Show(this);
        }
    }
}
