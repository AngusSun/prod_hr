﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.XSSF.UserModel;
using NLog;
using System.IO;

namespace CS_TimeSheet
{
    public partial class FrmCS202 : Form
    {

        // Logger
        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();


        public FrmCS202()
        {
            InitializeComponent();
        }

        private void bntExport_Click(object sender, EventArgs e)
        {
            Handle_SQL handle_SQL = new Handle_SQL();
            string sSql;
 
            sSql = @"select   work_day as 工作日期,  cust_name as 客戶名稱, work_loc as  工作區域, wo_no as 服務單, 
                   mach_no as 機型, emp_no as 工號, emp_name as 姓名, service_item as 工作項目,
                   service_desc as 工作進度, wrok_hour as 工時 , seq_no as 報工單序號 from   public.cs_timesheet  where  1=1 ";
            // where condition
            //if (comboEmpNo_Q.Text != "")
            //{
            //    sSql += " and  emp_no ='" + comboEmpNo_Q.SelectedValue.ToString().Split(',')[0] + "'";
            //}

            sSql += " and  work_day between '" + dt_Start.Value.ToString("yyyyMMdd") + "' and '" + dt_End.Value.ToString("yyyyMMdd") + "'";
 

            logger.Trace(sSql);

            DataTable dDT = new DataTable();
            dDT = handle_SQL.Query(sSql);

            

            // If directory does not exist  
            if (!Directory.Exists("D:\\工作日誌匯出\\"))
            {
                Directory.CreateDirectory("D:\\工作日誌匯出\\");
            }
            string Outpath = "D:\\工作日誌匯出\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".xlsx";

            DataTableToExcel(dDT, Outpath);//匯出Excel
        }


        /// <summary>
        /// 將DataTable(DataSet)匯出到Execl檔案
        /// </summary>
        /// <param name="dataSet">傳入一個DataSet</param>
        /// <param name="Outpath">匯出路徑 </param>
        /// <returns>回傳一個Bool型別的值，表示是否匯出成功</returns>
        /// True表示匯出成功，Flase表示匯出失敗
         

        private void DataTableToExcel(DataTable dt, string Outpath)
        {
            // 建立工作簿
            IWorkbook wb = new XSSFWorkbook();

            // .xls
            // IWorkbook wb = new HSSFWorkbook();

            using (FileStream fs = File.Create(Outpath))
            {
                // 建立名為 Simple 的工作表
                ISheet sheet = wb.CreateSheet("工作日誌");

                int i = 0;
                int j = 0;

                #region Title

                // 建立新的 row 給標題用
                sheet.CreateRow(0);

                for (i = 0; i < dt.Columns.Count; i++)
                {
                    // 取得已建立的 row ，再建立 cell，最後再配置值給 cell
                    sheet.GetRow(0).CreateCell(i).SetCellValue(dt.Columns[i].ColumnName);
                }

                #endregion

                #region Content

                // 走訪 dt
                for (i = 1; i <= dt.Rows.Count; i++)
                {
                    sheet.CreateRow(i);

                    for (j = 0; j < dt.Columns.Count; j++)
                    {
                        // 因為建立過的 row 或 cell 再次建立會覆蓋原有的值，所以建立過的物件使用 Get 取得再設置 Value
                        sheet.GetRow(i).CreateCell(j).SetCellValue(dt.Rows[i - 1][j].ToString());
                    }
                }
                #endregion

                // 將 wb 寫出到file stream
                wb.Write(fs);

                // 釋放資源
                wb.Close();
                wb = null;
                sheet = null;
            }
            MessageBox.Show("工作日誌匯出完成", "售服報工作業", MessageBoxButtons.OK, MessageBoxIcon.Information);
        
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmCS202_Load(object sender, EventArgs e)
        {
            dt_Start.Value = DateTime.Today.AddDays(-3); ;
            dt_End.Value = DateTime.Today;
        }

        private void Open_Excel(string destinationPath)
        {
            try
            {
                 
                using (FileStream fs = new FileStream(destinationPath, FileMode.Open))
                {
                    XSSFWorkbook wb = new XSSFWorkbook(fs);  // <- Error here
                    XSSFSheet hst;
                    hst = (XSSFSheet)wb.GetSheetAt(0);
                    string strSheetname = hst.SheetName;
                    XSSFRow hr;
                    hr = (XSSFRow)hst.GetRow(1);
                    string value = hr.GetCell(1).ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("CheckData Error:" + ex.Message);
            }
        }
    }


    
 
}
