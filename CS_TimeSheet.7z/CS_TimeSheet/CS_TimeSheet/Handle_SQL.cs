﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using Npgsql;
using NLog;


namespace CS_TimeSheet
{
    public class Handle_SQL
    {
        public   Handle_SQL()
        {
        }
      
        // Logger
        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();
        NpgsqlConnection  conn = new NpgsqlConnection("Host=;Port=;Username=;Password=;Database=;");

        public void Insert(string cmdText)
        {
            //Insert records
            conn.Open();

            using (var transaction = conn.BeginTransaction(IsolationLevel.Serializable))
            using (var command = new NpgsqlCommand(cmdText, conn, transaction))
            {
                command.CommandTimeout = 120;
                try
                {
                    command.ExecuteNonQuery();
                    transaction.Commit();
                }
                catch (NpgsqlException)
                {
                    throw;
                }
            }
         

        }

        public void Update(string cmdText)
        {
            //Update records
            conn.Open();
            NpgsqlCommand cmd3 = new NpgsqlCommand(cmdText, conn);
            cmd3.ExecuteNonQuery();
            conn.Close();
         
        }

        public void Delete(string cmdText)
        {
            //Delete records 
        
            conn.Open();
            NpgsqlCommand cmd4 = new NpgsqlCommand(cmdText, conn);
            cmd4.ExecuteNonQuery();
            conn.Close();
                   
                

        }

        public DataTable Query(string cmdText )
        {
            //Search records
            NpgsqlCommand cmd2 = new NpgsqlCommand(cmdText, conn);
            NpgsqlDataAdapter sd = new NpgsqlDataAdapter(cmd2);
            DataTable dDT = new DataTable("dDT");
            sd.Fill(dDT);
            return dDT;
        }
    }
}
