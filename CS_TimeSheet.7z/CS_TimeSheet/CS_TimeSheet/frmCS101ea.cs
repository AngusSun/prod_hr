﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NLog;
namespace CS_TimeSheet
{
    public partial class frmCS101ea : Form
    {
        // Logger
        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();
        private string ex_mode;
        public List<string> _emp = new List<string>();

        public frmCS101ea(string mode)
        {
            InitializeComponent();
            ex_mode = mode;
        }

        private void frmCS101ea_Load(object sender, EventArgs e)
        {

            comboBox1.SelectedIndex = 0;
            //   MessageBox.Show("資料 MODE = !!" + ex_mode, " 售服人員資料維護", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (ex_mode == "E")
            {
                handle_editTransfer();
            }
       
            
        }


        private void handle_editTransfer ()
        {
            string dept = string.Empty;
            switch (_emp[0] )
            {
                case "233":
                    comboBox1.SelectedIndex = 0;
                    break;
                case "242":
                    comboBox1.SelectedIndex = 1;
                    break;
                case "243":
                    comboBox1.SelectedIndex = 2;
                    break;
            }
            txEmpNo.Text = _emp[1];
            txEmp_name.Text = _emp[2];
            txEmpNo.BackColor = Color.LightYellow;
            txEmpNo.Enabled = false;
        }
        private string Validations()
        {
            if (string.IsNullOrWhiteSpace(txEmpNo.Text))
                return "工號不可空白!";
            if (string.IsNullOrWhiteSpace(comboBox1.Text))
                return "部門不可空白!";
            if (string.IsNullOrWhiteSpace(txEmp_name.Text))
                return "姓名不可空白!";
            //if (string.IsNullOrWhiteSpace(txWH.Text))
            //    return "工時不可空白!";
            //if (string.IsNullOrWhiteSpace(txCust.Text))
            //    return "客戶不可空白!";

            return string.Empty;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string sMsg = string.Empty;
            sMsg = Validations();

            if (sMsg != "")
            {
             MessageBox.Show(sMsg, " 售服人員資料維護", MessageBoxButtons.OK, MessageBoxIcon.Information);
             return;
            }

            string dept = string.Empty;
            switch (comboBox1.SelectedIndex.ToString())
            {
                case "0":
                    dept = "233";
                    break;
                case "1":
                    dept = "242";
                    break;
                case "2":
                    dept = "243";
                    break;
             }
            // 非A則E
            if (ex_mode =="A")
            {
                DataAppend(dept);
            }
            else
            {
                DataEdit(dept);
            }
        }
        
        // 資料新增模式 
        private void DataAppend  (string dept)
        {
            try
            {
 
                Handle_SQL handle_SQL = new Handle_SQL();

                string insertSql;

                insertSql = string.Format("insert into  cs_staff (dep_no,emp_no,emp_name) values ('{0}','{1}','{2}') ", dept, txEmpNo.Text, txEmp_name.Text);
                logger.Trace(insertSql);
                handle_SQL.Insert(insertSql);
                MessageBox.Show("資料新增完成 !!", "售服人員資料維護", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {

                logger.Error(ex, "Error");
                MessageBox.Show("資料新增失敗 !!" + "\r\n" + ex.ToString(), "售服人員資料維護", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        // 資料編輯模式 
        private void DataEdit(string dept)
        {
           try
            {

                Handle_SQL handle_SQL = new Handle_SQL();

                string updSql;

                updSql = string.Format(" UPDATE  cs_staff SET dep_no = '{0}', emp_no ='{1}', emp_name ='{2}',  modify_time = now()  WHERE emp_no='{3}';  ", dept, txEmpNo.Text, txEmp_name.Text,txEmpNo.Text);
                logger.Trace(updSql);
                handle_SQL.Update(updSql);
                MessageBox.Show("資料修改完成 !!", "售服人員資料維護", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {

                logger.Error(ex, "Error");
                MessageBox.Show("資料修改失敗 !!" + "\r\n" , "售服人員資料維護", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }
    }
}
